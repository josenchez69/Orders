package com.TouresBalon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TouresBalonApplication {

	public static void main(String[] args) {
		SpringApplication.run(TouresBalonApplication.class, args);
	}

}
