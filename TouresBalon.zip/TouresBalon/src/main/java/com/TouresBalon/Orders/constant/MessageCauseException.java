package com.TouresBalon.Orders.constant;

public class MessageCauseException {

	/**
	 * Messages Exception UserService
	 */
	public static final String ORDER_CAUSE_EXCEPTION = "Could not create Order ";
	/**
	 * Messages Exception UserOther
	 */
}
