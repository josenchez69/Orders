package com.TouresBalon.Orders.constant;

public class MessageServiceException {
	public static final String ORDER_EXCEPTION = "An error occurred during execute UserService ";
}
