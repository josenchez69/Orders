package com.TouresBalon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TouresBalonApplicationTests {

	@Test
	void contextLoads() {
	}

}
